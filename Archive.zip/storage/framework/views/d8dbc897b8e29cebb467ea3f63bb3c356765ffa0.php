<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link href="<?php echo e(asset('js/components/main.css')); ?>" rel="stylesheet">
    
    <style>
        @font-face{
            font-family:element-icons;
            src: url('<?php echo e(asset('js/fonts/element-icons.ttf')); ?>');
        }
    </style>
</head>
<body>
<?php if(Auth::check()): ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'isLoggedin' => true,
            'user' => Auth::user()
        ]); ?>

    </script>
<?php else: ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'isLoggedin' => false
        ]); ?>

    </script>
<?php endif; ?>
<?php phpinfo()?>
    <div id="app">
        <master></master>
    </div>
    <script src="<?php echo e(asset('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/calculator.test/resources/views/app.blade.php ENDPATH**/ ?>