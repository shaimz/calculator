<!DOCTYPE html>
<html>
<head>
    <title>Contacts</title>
    <style type="text/css">
        #contacts {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #contacts td, #contacts th {
            border: 1px solid #fff;
            padding: 8px;
        }

        #contacts tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #contacts tr:hover {
            background-color: #ddd;
        }

        #contacts th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #a1a7a7;
            color: #111;
        }

        .main-container {
            float: none;
            position: relative;
            background-color: #fff;
            padding: 8px;
            border: 1px solid #fff;
            margin: 0 auto;
        }

        .table-container {
            width: 75%;
        }

        .heading-item a {
            text-align: right;
        }

        .heading {
            padding: 10px 0px;
        }

        .heading p {
            font-size: 0;
        }

        .heading p span {
            width: 50%;
            display: inline-block;
        }

        .heading p span.align-right {
            text-align: right;
        }

        span a {
            font-size: 16px;
        }
    </style>
</head>
<body>
<div class="main-container">
    <div class="table-container">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><?php echo e($group); ?></h2>
            <table id="contacts">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Portions</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($name): ?>
                        <tr>
                            <td><?php echo e($food['id']); ?></td>
                            <td><?php echo e($food['name']); ?></td>
                            <td><?php echo e($food['portions']); ?></td>
                            <td><?php echo e($food['price']); ?></td>
                            <td><?php echo e($food['total']); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <h2 style="text-align: right;margin:20px 0;">Total sum: <?php echo e($total); ?></h2>
    </div>
</div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/calculator.test/resources/views/menu/pdf.blade.php ENDPATH**/ ?>